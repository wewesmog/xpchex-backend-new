"""
Graph Building Module
"""
