"""
Quiz Generator Application Package
"""
